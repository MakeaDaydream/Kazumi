class Road {
  String name;
  List<String> data;

  Road({
    required this.name,
    required this.data,
  });
}